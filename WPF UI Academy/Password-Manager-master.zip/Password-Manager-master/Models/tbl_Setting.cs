﻿namespace Models
{
    public class tbl_Setting
    {
        public int id { get; set; }

        public string username { get; set; }

        public string password { get; set; }

        public bool isLock { get; set; }

        public bool isDark { get; set; }

    }
}
