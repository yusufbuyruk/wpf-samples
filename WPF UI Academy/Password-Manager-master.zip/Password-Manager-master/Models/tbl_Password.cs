﻿namespace Models
{
    public class tbl_Password
    {
        public int id { get; set; }

        public string name { get; set; }

        public string description { get; set; }

        public string username { get; set; }

        public string password { get; set; }

        public string color { get; set; }
    }
}
